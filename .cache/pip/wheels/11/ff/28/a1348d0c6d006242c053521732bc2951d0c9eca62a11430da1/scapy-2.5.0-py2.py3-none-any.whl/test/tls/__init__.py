# SPDX-License-Identifier: GPL-2.0-only
# This file is part of Scapy
# See https://scapy.net/ for more information
# Copyright (C) 2016 Maxence Tury <maxence.tury@ssi.gouv.fr>

"""
Examples and test PKI for the TLS module.
"""

